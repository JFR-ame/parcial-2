export const translations = {
  es: {
    mainTitle: "Adopción de Robots",
    headerId: "#",
    headerName: "Nombre",
    headerModel: "Modelo",
    headerCompany: "Empresa",
    yearLabel: "Año de fabricación:",
    capacityLabel: "Capacidad de procesamiento:",
    humorLabel: "Humor:",
    additionalLabel: "Características adicionales:",
  },
  en: {
    mainTitle: "Robot Adoption",
    headerId: "#",
    headerName: "Name",
    headerModel: "Model",
    headerCompany: "Company",
    yearLabel: "Manufacturing year:",
    capacityLabel: "Processing capacity:",
    humorLabel: "Humor:",
    additionalLabel: "Additional features:",
  },
}
