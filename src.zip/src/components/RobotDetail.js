export default function RobotDetail({ robot, translations }) {
  if (!robot) {
    return null
  }

  const handleImageError = (e) => {
    e.target.src = "https://via.placeholder.com/200x200/6c757d/ffffff?text=Robot"
  }

  return (
    <div className="card robot-detail-card">
      <div className="card-body text-center">
        <img
          src={robot.imagen || "/placeholder.svg"}
          alt={robot.nombre}
          className="img-fluid mb-3 robot-image"
          onError={handleImageError}
        />
        <h5 className="card-title">{robot.nombre}</h5>
        <div className="robot-details">
          <p>
            <strong>{translations.yearLabel}</strong> {robot.año}
          </p>
          <p>
            <strong>{translations.capacityLabel}</strong> {robot.capacidadProcesamiento}
          </p>
          <p>
            <strong>{translations.humorLabel}</strong> {robot.humor}
          </p>
          <hr />
          <h6>{translations.additionalLabel}</h6>
          <ul className="list-unstyled">
            {robot.adicionales.map((feature, index) => (
              <li key={index}>{feature}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}
