"use client"

export default function LanguageSelector({ currentLanguage, onLanguageChange }) {
  return (
    <div className="language-selector">
      <button
        className={`btn btn-outline-primary btn-sm me-2 ${currentLanguage === "es" ? "active" : ""}`}
        onClick={() => onLanguageChange("es")}
      >
        Español
      </button>
      <button
        className={`btn btn-outline-primary btn-sm ${currentLanguage === "en" ? "active" : ""}`}
        onClick={() => onLanguageChange("en")}
      >
        English
      </button>
    </div>
  )
}
