"use client"

export default function RobotTable({ robots, selectedRobot, onRobotSelect, translations }) {
  return (
    <div className="card">
      <div className="card-body">
        <table className="table table-striped table-hover">
          <thead className="table-dark">
            <tr>
              <th>{translations.headerId}</th>
              <th>{translations.headerName}</th>
              <th>{translations.headerModel}</th>
              <th>{translations.headerCompany}</th>
            </tr>
          </thead>
          <tbody>
            {robots.map((robot) => (
              <tr
                key={robot.id}
                className={`robot-row ${selectedRobot?.id === robot.id ? "selected" : ""}`}
                onClick={() => onRobotSelect(robot)}
                style={{ cursor: "pointer" }}
              >
                <td>{robot.id}</td>
                <td>{robot.nombre}</td>
                <td>{robot.modelo}</td>
                <td>{robot.empresa}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
