"use client"

import { useState, useEffect } from "react"
import RobotTable from "./components/RobotTable"
import RobotDetail from "./components/RobotDetail"
import LanguageSelector from "./components/LanguageSelector"
import { translations } from "./utils/Translations"

export default function Home() {
  const [robots, setRobots] = useState([])
  const [selectedRobot, setSelectedRobot] = useState(null)
  const [currentLanguage, setCurrentLanguage] = useState("es")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadRobots()
  }, [])

  const loadRobots = async () => {
    try {
      const response = await fetch(
        "https://gist.githubusercontent.com/josejbocanegra/aa5fb56863c326ebb3d558f8a225d223/raw/5c55db5012e5fc24862e05847ff1f2927aea11db/robots.json",
      )
      const data = await response.json()
      setRobots(data)
    } catch (error) {
      console.error("Error loading robots:", error)
      // Fallback data
      setRobots([
        {
          id: 1,
          nombre: "WAL-E",
          modelo: "Limpieza",
          empresa: "Axiom",
          año: 2800,
          capacidadProcesamiento: "1 TB",
          humor: "Inquisitivo",
          imagen: "https://via.placeholder.com/200x200/007bff/ffffff?text=WAL-E",
          adicionales: ["Compactador de basura", "Navegación autónoma", "Reconocimiento de objetos"],
        },
      ])
    } finally {
      setLoading(false)
    }
  }

  const handleRobotSelect = (robot) => {
    setSelectedRobot(robot)
  }

  const handleLanguageChange = (language) => {
    setCurrentLanguage(language)
  }

  const t = translations[currentLanguage]

  if (loading) {
    return (
      <div className="container mt-4">
        <div className="d-flex justify-content-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mt-4">
      {/* Header with language selector */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1 className="main-title">{t.mainTitle}</h1>
        <LanguageSelector currentLanguage={currentLanguage} onLanguageChange={handleLanguageChange} />
      </div>

      {/* Main content */}
      <div className="row">
        <div className="col-md-8">
          <RobotTable
            robots={robots}
            selectedRobot={selectedRobot}
            onRobotSelect={handleRobotSelect}
            translations={t}
          />
        </div>
        <div className="col-md-4">
          <RobotDetail robot={selectedRobot} translations={t} />
        </div>
      </div>
    </div>
  )
}
